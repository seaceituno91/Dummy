package cl.vidasecurity.readcs;

import com.ibm.broker.config.proxy.BrokerProxy;
import com.ibm.broker.config.proxy.ConfigManagerProxyLoggedException;
import com.ibm.broker.config.proxy.ConfigManagerProxyPropertyNotInitializedException;
import com.ibm.broker.config.proxy.ConfigurableService;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessageAssembly;

public class ReadConfigurableService extends MbJavaComputeNode{
	
	private static final String UserDefined = "UserDefined";
	private static final String Empty = "";
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {	}
	
	/*private static void esperar(BrokerProxy bp) throws Exception {
		short contador = 0;
		short limite = 4;
		
        while (!bp.hasBeenPopulatedByBroker()) {
    		try {
				contador++;
				Thread.sleep(100);
    		} catch(InterruptedException e){
    			throw new Exception("[t1] Problema con el Nodo, error: " + e.getMessage(), e);
			}
    		
			if (contador > limite) {
				throw new Exception("[t2] Ha ucurrido un problema con el Nodo.");
			}
        }
	}*/
	
	private static String recuperaPropiedad(String servicio, String propiedad, BrokerProxy bp) throws Exception {
		String retorno = Empty;
		
		try {
			//ConfigurableService[] arrayConfServ = bp.getConfigurableServices(UserDefined);
			ConfigurableService confServ = bp.getConfigurableService(UserDefined, servicio);
			//String servicioMayusc = servicio.toUpperCase().trim();
			/*int largo = arrayConfServ.length;
			
			for (int i = 0; i < largo; i++) {
				if (arrayConfServ[i].getName().toString().toUpperCase().trim().equals(servicioMayusc)) {
					retorno = arrayConfServ[i].getProperties().getProperty(propiedad);
					break;
				} else {
					continue;
				}
			}*/
			retorno = confServ.getProperties().getProperty(propiedad);
		} catch (ConfigManagerProxyPropertyNotInitializedException e) {
			throw new Exception("[r1] Problema al recuperar la propiedad, error: " + e.getMessage(), e);
		} catch (Exception ex) {
			throw new Exception("[r2] Problema al recuperar la propiedad, error: " + ex.getMessage(), ex);
		}
		
		return retorno;
	}

	public static String getPropiedad(String propiedad, String servicio){
		BrokerProxy bp = null;
		String valor = Empty;
		
	    try{
	         bp = BrokerProxy.getLocalInstance();
	         //esperar(bp);
	         valor = recuperaPropiedad(servicio, propiedad, bp);
	    } catch (ConfigManagerProxyLoggedException e) {
	    	valor = "[gp1] Error al recuperar la propiedad, error: " + e.getMessage();
	    } catch (Exception ex){
	    	valor = "[gp2] Error al recuperar la propiedad, error: " + ex.getMessage();
	    } finally {
	    	bp.disconnect();
	    }
	    
	    return valor;
	}
	
	/*public static String getPropiedad(String propiedad, String servicio){		
	      try{
	           BrokerProxy bp = BrokerProxy.getLocalInstance();
	           short c = 0;
	           while(!bp.hasBeenPopulatedByBroker()){
	                try{
	                     c++;    //loop count, in the rare case it fails, we need to leave the loop
	                     Thread.sleep(100);
	                }catch(InterruptedException e){
	                     //return "-1";
	                     return "[a] - " + e.getMessage();
	                }
	                if(c > 4)
	                    //return "-1";
	                	return "[b] - CUEK!!!";
	           }
	           try{
	                ConfigurableService udcs = bp.getConfigurableService("UserDefined", servicio);
	                java.util.Properties props = udcs.getProperties();                
	                return props.getProperty(propiedad);	                
	           }catch(ConfigManagerProxyPropertyNotInitializedException e){
	                //return "-1";
	                return "[c] - " + e.getMessage();
	           }
	      }catch(ConfigManagerProxyLoggedException e){
	           //return "-1";
	           return "[d] - " + e.getMessage();
	      }	      
	}*/


}
